"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";

interface SocialAccount {
  id: string;
  platform: string;
  handle: string;
  connected: boolean;
}

export function useSocialAccounts() {
  const { data: session } = useSession();
  const [accounts, setAccounts] = useState<SocialAccount[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAccounts = async () => {
      if (!session?.user) return;

      try {
        const response = await fetch("/api/social/accounts");
        if (!response.ok) {
          throw new Error("Failed to fetch social accounts");
        }

        const data = await response.json();
        setAccounts(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to fetch accounts");
      } finally {
        setIsLoading(false);
      }
    };

    fetchAccounts();
  }, [session]);

  const refreshAccounts = () => {
    setIsLoading(true);
    setError(null);
    fetchAccounts();
  };

  return {
    accounts,
    isLoading,
    error,
    refreshAccounts
  };
}