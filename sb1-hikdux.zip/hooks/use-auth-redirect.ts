"use client";

import { useEffect, useState } from "react";
import { useRouter, usePathname, useSearchParams } from "next/navigation";
import { useSession } from "next-auth/react";

export function useAuthRedirect() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const from = searchParams.get("from") || "/dashboard";
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      if (status === "loading") return;

      const isAuthPage = pathname.startsWith("/auth");

      if (session && isAuthPage) {
        router.push(from);
      } else if (!session && !isAuthPage && pathname !== "/") {
        router.push(`/auth/login?from=${encodeURIComponent(pathname)}`);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred during authentication");
    }
  }, [session, status, pathname, router, from]);

  return { session, status, error };
}