"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { Session } from "next-auth";
import { useSession } from "next-auth/react";
import { Loading } from "@/components/ui/loading";

interface AuthContextType {
  session: Session | null;
  status: "loading" | "authenticated" | "unauthenticated";
  error: string | null;
}

const AuthContext = createContext<AuthContextType>({
  session: null,
  status: "loading",
  error: null,
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const { data: session, status } = useSession();
  const router = useRouter();
  const pathname = usePathname();
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      const protectedRoutes = ["/dashboard"];
      const isProtectedRoute = protectedRoutes.some(route => 
        pathname.startsWith(route)
      );
      const isAuthPage = pathname.startsWith("/auth");

      if (status === "loading") {
        return;
      }

      if (!session && isProtectedRoute) {
        router.push(`/auth/login?from=${encodeURIComponent(pathname)}`);
      } else if (session && isAuthPage) {
        router.push("/dashboard");
      }

      setIsLoading(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
      setIsLoading(false);
    }
  }, [session, status, pathname, router]);

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loading size="lg" />
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ session, status, error }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);