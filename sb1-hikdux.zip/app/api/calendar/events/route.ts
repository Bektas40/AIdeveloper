import { NextResponse } from 'next/server';
import { z } from 'zod';

const eventSchema = z.object({
  title: z.string(),
  content: z.string(),
  scheduledFor: z.string().datetime(),
  platforms: z.array(z.enum(['twitter', 'instagram', 'facebook'])),
  status: z.enum(['draft', 'scheduled', 'published']),
});

// Mock data - Replace with database implementation
const events = [
  {
    id: '1',
    title: 'Product Launch',
    content: 'Exciting news! Our new feature is live...',
    scheduledFor: '2024-04-01T10:00:00Z',
    platforms: ['twitter', 'facebook'],
    status: 'scheduled'
  }
];

export async function GET() {
  try {
    return NextResponse.json(events);
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch events' },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const json = await req.json();
    const event = eventSchema.parse(json);
    
    // Add validation and database storage logic
    
    return NextResponse.json(event);
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to create event' },
      { status: 500 }
    );
  }
}