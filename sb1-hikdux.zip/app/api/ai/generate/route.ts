import { OpenAIStream, StreamingTextResponse } from 'ai';
import OpenAI from 'openai';
import { z } from 'zod';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const requestSchema = z.object({
  prompt: z.string(),
  platform: z.enum(['twitter', 'instagram', 'facebook']),
  tone: z.enum(['professional', 'casual', 'friendly', 'humorous']),
  length: z.enum(['short', 'medium', 'long']),
});

export async function POST(req: Request) {
  try {
    const json = await req.json();
    const { prompt, platform, tone, length } = requestSchema.parse(json);

    const response = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: `You are a social media expert. Create ${platform} content that is ${tone} in tone and ${length} in length.`,
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      stream: true,
    });

    const stream = OpenAIStream(response);
    return new StreamingTextResponse(stream);
  } catch (error) {
    return new Response('Error generating content', { status: 500 });
  }
}