import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { prisma } from "@/lib/prisma";
import { authOptions } from "../../auth/[...nextauth]/route";
import { z } from "zod";

const socialConnectSchema = z.object({
  platform: z.enum(["twitter", "instagram", "facebook", "youtube"]),
  handle: z.string().min(1),
});

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return NextResponse.json(
        { message: "Unauthorized" },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { platform, handle } = socialConnectSchema.parse(body);

    const user = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!user) {
      return NextResponse.json(
        { message: "User not found" },
        { status: 404 }
      );
    }

    const socialAccount = await prisma.socialAccount.upsert({
      where: {
        userId_platform: {
          userId: user.id,
          platform,
        },
      },
      update: {
        handle,
        connected: true,
      },
      create: {
        userId: user.id,
        platform,
        handle,
      },
    });

    return NextResponse.json(socialAccount);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { message: error.errors[0].message },
        { status: 400 }
      );
    }

    console.error("Social connect error:", error);
    return NextResponse.json(
      { message: "Failed to connect social account" },
      { status: 500 }
    );
  }
}