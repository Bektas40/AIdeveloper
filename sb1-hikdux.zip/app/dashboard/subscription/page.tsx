"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Loader2, CreditCard } from "lucide-react";

export default function Subscription() {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // Mock subscription data
  const subscription = {
    plan: "Professional",
    status: "active",
    trialEndsAt: "2024-04-20",
    nextBilling: "2024-04-21",
    amount: "$79.00",
    cardLast4: "4242",
  };

  const handleCancelSubscription = async () => {
    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Subscription cancelled",
        description: "Your subscription will end at the end of the current billing period.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to cancel subscription. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Subscription Management</h1>

        <Card className="p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold mb-1">Current Plan</h2>
              <p className="text-muted-foreground">Manage your subscription and billing</p>
            </div>
            <Badge variant="outline" className="text-orange-500 border-orange-500">
              {subscription.status === "active" ? "Active" : "Inactive"}
            </Badge>
          </div>

          <Table>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">Plan</TableCell>
                <TableCell>{subscription.plan}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Trial Ends</TableCell>
                <TableCell>{subscription.trialEndsAt}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Next Billing</TableCell>
                <TableCell>{subscription.nextBilling}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Amount</TableCell>
                <TableCell>{subscription.amount}/month</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Payment Method</TableCell>
                <TableCell className="flex items-center gap-2">
                  <CreditCard className="h-4 w-4" />
                  •••• {subscription.cardLast4}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>

          <div className="mt-6 flex gap-4">
            <Button variant="outline">Update Payment Method</Button>
            <Button 
              variant="destructive" 
              onClick={handleCancelSubscription}
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Cancelling...
                </>
              ) : (
                "Cancel Subscription"
              )}
            </Button>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Billing History</h2>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>Apr 1, 2024</TableCell>
                <TableCell>Professional Plan - Monthly</TableCell>
                <TableCell>{subscription.amount}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="text-green-500 border-green-500">
                    Paid
                  </Badge>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Mar 1, 2024</TableCell>
                <TableCell>Professional Plan - Monthly</TableCell>
                <TableCell>{subscription.amount}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="text-green-500 border-green-500">
                    Paid
                  </Badge>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </Card>
      </div>
    </div>
  );
}