"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, LineChart, PieChart } from "@/components/dashboard/charts";
import { DateRangePicker } from "@/components/dashboard/date-range-picker";

export default function Analytics() {
  const [dateRange, setDateRange] = useState<[Date | undefined, Date | undefined]>([
    new Date(new Date().setDate(new Date().getDate() - 30)),
    new Date()
  ]);
  const [platform, setPlatform] = useState("all");

  return (
    <div className="container py-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Analytics</h1>
        <div className="flex items-center gap-4">
          <Select value={platform} onValueChange={setPlatform}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select platform" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Platforms</SelectItem>
              <SelectItem value="twitter">Twitter</SelectItem>
              <SelectItem value="instagram">Instagram</SelectItem>
              <SelectItem value="facebook">Facebook</SelectItem>
            </SelectContent>
          </Select>
          <DateRangePicker 
            value={dateRange}
            onChange={setDateRange}
          />
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-8">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="engagement">Engagement</TabsTrigger>
          <TabsTrigger value="audience">Audience</TabsTrigger>
          <TabsTrigger value="content">Content Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-8">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Follower Growth</h3>
              <LineChart data={[]} />
            </Card>
            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Engagement Rate</h3>
              <LineChart data={[]} />
            </Card>
            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Post Performance</h3>
              <BarChart data={[]} />
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="engagement" className="space-y-8">
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Engagement by Type</h3>
              <PieChart data={[]} />
            </Card>
            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Engagement by Time</h3>
              <BarChart data={[]} />
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="audience" className="space-y-8">
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Audience Demographics</h3>
              <PieChart data={[]} />
            </Card>
            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Audience Growth</h3>
              <LineChart data={[]} />
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="content" className="space-y-8">
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Top Performing Posts</h3>
              <BarChart data={[]} />
            </Card>
            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Content Type Performance</h3>
              <PieChart data={[]} />
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}