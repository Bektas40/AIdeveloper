"use client";

import { useEffect, useState } from "react";
import { AnalyticsCard } from "@/components/dashboard/analytics-card";
import { ContentCalendar } from "@/components/dashboard/content-calendar";
import { AIContentGenerator } from "@/components/dashboard/ai-content-generator";
import { Card } from "@/components/ui/card";
import {
  Users,
  BarChart3,
  MessageSquare,
  Share2,
  Loader2
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface AnalyticsData {
  followers: {
    total: number;
    growth: number;
    platforms: {
      twitter: number;
      instagram: number;
      facebook: number;
    };
  };
  engagement: {
    rate: number;
    likes: number;
    comments: number;
    shares: number;
  };
  posts: {
    total: number;
    scheduled: number;
    performance: Array<{
      date: string;
      engagement: number;
    }>;
  };
}

export default function Dashboard() {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchAnalytics() {
      try {
        const response = await fetch('/api/analytics/overview');
        const data = await response.json();
        setAnalytics(data);
      } catch (error) {
        console.error('Failed to fetch analytics:', error);
      } finally {
        setIsLoading(false);
      }
    }

    fetchAnalytics();
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-8">Dashboard</h1>

      {/* Analytics Overview */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
        <AnalyticsCard
          title="Total Followers"
          value={analytics?.followers.total.toLocaleString() || "0"}
          change={analytics?.followers.growth}
          icon={<Users className="h-5 w-5" />}
        />
        <AnalyticsCard
          title="Engagement Rate"
          value={`${analytics?.engagement.rate || 0}%`}
          icon={<BarChart3 className="h-5 w-5" />}
        />
        <AnalyticsCard
          title="Total Comments"
          value={analytics?.engagement.comments.toLocaleString() || "0"}
          icon={<MessageSquare className="h-5 w-5" />}
        />
        <AnalyticsCard
          title="Total Shares"
          value={analytics?.engagement.shares.toLocaleString() || "0"}
          icon={<Share2 className="h-5 w-5" />}
        />
      </div>

      {/* Engagement Chart */}
      <Card className="p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">Engagement Overview</h2>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={analytics?.posts.performance || []}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tickFormatter={(value) => new Date(value).toLocaleDateString()}
              />
              <YAxis />
              <Tooltip 
                labelFormatter={(value) => new Date(value).toLocaleDateString()}
              />
              <Line 
                type="monotone" 
                dataKey="engagement" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <div className="grid gap-8 lg:grid-cols-2">
        {/* Content Calendar */}
        <ContentCalendar />

        {/* AI Content Generator */}
        <AIContentGenerator />
      </div>
    </div>
  );
}