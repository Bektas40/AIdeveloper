import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Flame, BarChart3, Users } from "lucide-react";

export default function Home() {
  return (
    <div className="flex flex-col items-center">
      <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-gradient-to-b from-white to-orange-50 dark:from-gray-900 dark:to-gray-800">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                Ignite Your Social Media Presence with AI
              </h1>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                Let SocialFlare's AI power your content creation, scheduling, and analytics for explosive growth.
              </p>
            </div>
            <div className="space-x-4">
              <Link href="/pricing">
                <Button size="lg" className="bg-orange-600 hover:bg-orange-700">
                  Get Started <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="w-full py-12 md:py-24 lg:py-32 bg-white dark:bg-gray-900">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-3 lg:gap-12">
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <Flame className="h-12 w-12 mb-4 text-orange-500" />
              <h3 className="text-xl font-bold mb-2">AI-Powered Content</h3>
              <p className="text-gray-500 dark:text-gray-400">
                Generate engaging content automatically with our advanced AI algorithms.
              </p>
            </Card>
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <BarChart3 className="h-12 w-12 mb-4 text-orange-500" />
              <h3 className="text-xl font-bold mb-2">Analytics & Insights</h3>
              <p className="text-gray-500 dark:text-gray-400">
                Track your performance with detailed analytics and actionable insights.
              </p>
            </Card>
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <Users className="h-12 w-12 mb-4 text-orange-500" />
              <h3 className="text-xl font-bold mb-2">Audience Growth</h3>
              <p className="text-gray-500 dark:text-gray-400">
                Grow your audience organically with smart engagement strategies.
              </p>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}