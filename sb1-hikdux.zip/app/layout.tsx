import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/toaster';
import Navigation from '@/components/navigation';
import { AuthProvider } from '@/providers/auth-provider';
import { SessionProvider } from '@/providers/session-provider';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'SocialFlare - AI-Powered Social Media Marketing',
  description: 'Automate your social media presence with AI-driven content creation, scheduling, and analytics.',
  keywords: 'social media marketing, AI content creation, social media automation, influencer marketing',
  openGraph: {
    title: 'SocialFlare - AI-Powered Social Media Marketing',
    description: 'Automate your social media presence with AI-driven content creation, scheduling, and analytics.',
    images: ['https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=1200&h=630&fit=crop'],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'SocialFlare - AI-Powered Social Media Marketing',
    description: 'Automate your social media presence with AI-driven content creation, scheduling, and analytics.',
    images: ['https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=1200&h=630&fit=crop'],
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className} suppressHydrationWarning>
        <SessionProvider>
          <ThemeProvider
            attribute="class"
            defaultTheme="system"
            enableSystem
            disableTransitionOnChange
          >
            <AuthProvider>
              <Navigation />
              <main className="flex-1">
                {children}
              </main>
              <Toaster />
            </AuthProvider>
          </ThemeProvider>
        </SessionProvider>
      </body>
    </html>
  );
}