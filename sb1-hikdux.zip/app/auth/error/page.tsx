import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";
import Link from "next/link";

export default function AuthError() {
  return (
    <div className="container max-w-md py-12">
      <Card className="p-6">
        <div className="flex flex-col items-center text-center">
          <AlertTriangle className="h-12 w-12 text-destructive mb-4" />
          <h1 className="text-2xl font-bold mb-2">Authentication Error</h1>
          <p className="text-muted-foreground mb-6">
            There was a problem authenticating your account. Please try again or contact support if the problem persists.
          </p>
          <div className="space-y-4 w-full">
            <Link href="/auth/login">
              <Button className="w-full">Try Again</Button>
            </Link>
            <Link href="/">
              <Button variant="outline" className="w-full">
                Return Home
              </Button>
            </Link>
          </div>
        </div>
      </Card>
    </div>
  );
}