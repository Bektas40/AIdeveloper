"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { ArrowRight, Instagram, Twitter, Facebook, Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const formSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
});

export default function GetStarted() {
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    try {
      setIsLoading(true);
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      setStep(2);
      toast({
        title: "Success!",
        description: "Your account has been created.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  const handleSocialConnect = async (platform: string) => {
    try {
      setIsLoading(true);
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast({
        title: "Connected!",
        description: `Successfully connected to ${platform}.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to connect to ${platform}. Please try again.`,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container max-w-4xl py-12">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold tracking-tight mb-2">Get Started with SocialFlare</h1>
        <p className="text-muted-foreground">Set up your account in just a few steps</p>
      </div>

      <Card className="p-6">
        {step === 1 ? (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Your name" {...field} disabled={isLoading} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="your@email.com" type="email" {...field} disabled={isLoading} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Please wait
                  </>
                ) : (
                  <>
                    Continue <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </form>
          </Form>
        ) : (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <h2 className="text-xl font-semibold mb-2">Connect Your Social Media Accounts</h2>
              <p className="text-muted-foreground">Choose the platforms you want to manage</p>
            </div>
            <div className="grid gap-4">
              <Button
                variant="outline"
                className="h-16 justify-start gap-4"
                onClick={() => handleSocialConnect("Instagram")}
                disabled={isLoading}
              >
                <Instagram className="h-6 w-6" />
                <span>Connect Instagram</span>
              </Button>
              <Button
                variant="outline"
                className="h-16 justify-start gap-4"
                onClick={() => handleSocialConnect("Twitter")}
                disabled={isLoading}
              >
                <Twitter className="h-6 w-6" />
                <span>Connect Twitter</span>
              </Button>
              <Button
                variant="outline"
                className="h-16 justify-start gap-4"
                onClick={() => handleSocialConnect("Facebook")}
                disabled={isLoading}
              >
                <Facebook className="h-6 w-6" />
                <span>Connect Facebook</span>
              </Button>
            </div>
            <Button className="w-full" onClick={() => window.location.href = "/dashboard"} disabled={isLoading}>
              Complete Setup <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        )}
      </Card>
    </div>
  );
}