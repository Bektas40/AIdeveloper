import { PricingCard } from "@/components/pricing/pricing-card";
import { Button } from "@/components/ui/button";
import Link from "next/link";

const pricingPlans = [
  {
    name: "Starter",
    price: "$49",
    description: "Perfect for individuals and small creators",
    features: [
      "AI content generation (50/month)",
      "Basic analytics dashboard",
      "3 social media accounts",
      "Content calendar",
      "Auto-posting scheduler",
      "Basic engagement metrics",
      "Email support",
      "Mobile app access"
    ],
    ctaLink: "/signup?plan=starter",
    ctaText: "Start Free Trial",
    popular: false
  },
  {
    name: "Professional",
    price: "$99",
    description: "Ideal for growing businesses and influencers",
    features: [
      "AI content generation (200/month)",
      "Advanced analytics & reports",
      "15 social media accounts",
      "Content calendar & planner",
      "Smart scheduling algorithm",
      "Competitor analysis",
      "Hashtag recommendations",
      "Priority email & chat support",
      "Team collaboration (3 seats)",
      "Custom posting schedule",
      "Social listening tools"
    ],
    ctaLink: "/signup?plan=professional",
    ctaText: "Start Free Trial",
    popular: true
  },
  {
    name: "Enterprise",
    price: "Custom",
    description: "For large organizations and agencies",
    features: [
      "Unlimited AI content generation",
      "Enterprise analytics suite",
      "Unlimited social accounts",
      "Advanced content planning",
      "Custom AI training",
      "Dedicated success manager",
      "24/7 priority support",
      "Custom integrations",
      "API access",
      "Unlimited team seats",
      "Advanced security features",
      "Custom reporting",
      "SLA guarantees"
    ],
    ctaLink: "/contact-sales",
    ctaText: "Contact Sales",
    popular: false
  }
];

export default function Pricing() {
  return (
    <div className="container py-12 md:py-24 lg:py-32">
      <div className="text-center mb-12 md:mb-16">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">
          Simple, Transparent Pricing
        </h1>
        <p className="text-xl text-muted-foreground">
          Choose the perfect plan for your social media needs
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {pricingPlans.map((plan) => (
          <PricingCard key={plan.name} {...plan} />
        ))}
      </div>

      <div className="mt-16 text-center">
        <h2 className="text-2xl font-semibold mb-4">Need a Custom Solution?</h2>
        <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
          Our enterprise plan includes custom features, dedicated support, and flexible pricing based on your specific needs. Let's discuss how we can help your organization scale.
        </p>
        <Link href="/contact-sales">
          <Button size="lg" variant="outline">
            Contact Sales
          </Button>
        </Link>
      </div>
    </div>
  );
}