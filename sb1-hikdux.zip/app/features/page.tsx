import { Card } from "@/components/ui/card";
import { 
  Zap, 
  BarChart3, 
  Calendar, 
  Users, 
  Target, 
  Globe,
  MessageSquare,
  TrendingUp,
  Shield 
} from "lucide-react";

const features = [
  {
    icon: Zap,
    title: "AI Content Generation",
    description: "Create engaging posts automatically with our advanced AI algorithms tailored to your brand voice."
  },
  {
    icon: BarChart3,
    title: "Advanced Analytics",
    description: "Get deep insights into your social media performance with comprehensive analytics and reporting."
  },
  {
    icon: Calendar,
    title: "Smart Scheduling",
    description: "Schedule posts at optimal times with our AI-powered timing algorithm for maximum engagement."
  },
  {
    icon: Users,
    title: "Audience Insights",
    description: "Understand your audience better with detailed demographic and behavioral analytics."
  },
  {
    icon: Target,
    title: "Competitor Analysis",
    description: "Track and analyze your competitors' social media strategies and performance."
  },
  {
    icon: Globe,
    title: "Multi-Platform Support",
    description: "Manage all your social media accounts from a single, unified dashboard."
  },
  {
    icon: MessageSquare,
    title: "Engagement Management",
    description: "Respond to comments and messages across all platforms from one inbox."
  },
  {
    icon: TrendingUp,
    title: "Growth Tools",
    description: "Access powerful tools designed to grow your following and increase engagement."
  },
  {
    icon: Shield,
    title: "Brand Protection",
    description: "Monitor and protect your brand reputation across social media platforms."
  }
];

export default function Features() {
  return (
    <div className="container py-12 md:py-24 lg:py-32">
      <div className="text-center mb-12 md:mb-16">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">
          Powerful Features for Social Success
        </h1>
        <p className="text-xl text-muted-foreground max-w-[800px] mx-auto">
          Everything you need to manage, grow, and optimize your social media presence
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {features.map((feature) => {
          const Icon = feature.icon;
          return (
            <Card key={feature.title} className="p-6">
              <Icon className="h-12 w-12 mb-4 text-orange-500" />
              <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </Card>
          );
        })}
      </div>
    </div>
  );
}