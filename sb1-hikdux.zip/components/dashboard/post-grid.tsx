"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export function PostGrid() {
  // Mock data - Replace with API call
  const posts = [
    {
      id: "1",
      title: "Product Launch",
      content: "Exciting news! Our new feature is live...",
      platform: "twitter",
      status: "scheduled",
      scheduledFor: new Date(),
    }
  ];

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {posts.map((post) => (
        <Card key={post.id} className="p-4">
          <div className="flex flex-col h-full">
            <div className="flex justify-between items-start mb-4">
              <Badge variant="outline">
                {post.platform}
              </Badge>
              <Badge 
                variant={post.status === "published" ? "default" : "secondary"}
              >
                {post.status}
              </Badge>
            </div>
            <h4 className="font-medium mb-2">{post.title}</h4>
            <p className="text-muted-foreground text-sm flex-grow">
              {post.content}
            </p>
            <div className="mt-4 text-sm text-muted-foreground">
              {post.scheduledFor.toLocaleDateString()}
            </div>
          </div>
        </Card>
      ))}

      {posts.length === 0 && (
        <p className="text-muted-foreground text-center py-4 col-span-full">
          No posts available
        </p>
      )}
    </div>
  );
}