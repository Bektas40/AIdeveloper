"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface PostListProps {
  date?: Date;
}

export function PostList({ date }: PostListProps) {
  // Mock data - Replace with API call
  const posts = [
    {
      id: "1",
      title: "Product Launch",
      platform: "twitter",
      status: "scheduled",
      scheduledFor: new Date(),
    }
  ];

  return (
    <div className="space-y-4">
      {posts.map((post) => (
        <Card key={post.id} className="p-4">
          <div className="flex justify-between items-start">
            <div>
              <h4 className="font-medium">{post.title}</h4>
              <div className="flex gap-2 mt-2">
                <Badge variant="outline">
                  {post.platform}
                </Badge>
              </div>
            </div>
            <Badge 
              variant={post.status === "published" ? "default" : "secondary"}
            >
              {post.status}
            </Badge>
          </div>
        </Card>
      ))}

      {posts.length === 0 && (
        <p className="text-muted-foreground text-center py-4">
          No posts scheduled
        </p>
      )}
    </div>
  );
}