"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";
import { Plus } from "lucide-react";

interface Post {
  id: string;
  title: string;
  date: Date;
  platforms: string[];
  status: "draft" | "scheduled" | "published";
}

export function ContentCalendar() {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);

  // Mock data - Replace with API call
  const posts: Post[] = [
    {
      id: "1",
      title: "Product Feature Highlight",
      date: new Date(),
      platforms: ["twitter", "linkedin"],
      status: "scheduled"
    }
  ];

  const getDayPosts = (day: Date) => {
    return posts.filter(post => 
      post.date.toDateString() === day.toDateString()
    );
  };

  return (
    <Card className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Content Calendar</h2>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          New Post
        </Button>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Calendar
          mode="single"
          selected={date}
          onSelect={setDate}
          className="rounded-md border"
          components={{
            DayContent: ({ date }) => (
              <div className="relative">
                {date.getDate()}
                {getDayPosts(date).length > 0 && (
                  <div className="absolute bottom-0 left-1/2 -translate-x-1/2">
                    <div className="h-1 w-1 rounded-full bg-orange-500" />
                  </div>
                )}
              </div>
            ),
          }}
        />

        <div className="space-y-4">
          <h3 className="font-medium">
            {date?.toLocaleDateString("en-US", { 
              month: "long", 
              day: "numeric", 
              year: "numeric" 
            })}
          </h3>
          
          {getDayPosts(date || new Date()).map(post => (
            <Card 
              key={post.id} 
              className="p-4 cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => setSelectedPost(post)}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-medium">{post.title}</h4>
                  <div className="flex gap-2 mt-2">
                    {post.platforms.map(platform => (
                      <Badge key={platform} variant="outline">
                        {platform}
                      </Badge>
                    ))}
                  </div>
                </div>
                <Badge 
                  variant={post.status === "published" ? "default" : "secondary"}
                >
                  {post.status}
                </Badge>
              </div>
            </Card>
          ))}

          {getDayPosts(date || new Date()).length === 0 && (
            <p className="text-muted-foreground text-center py-4">
              No posts scheduled for this day
            </p>
          )}
        </div>
      </div>
    </Card>
  );
}