"use client";

import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import Link from "next/link";

interface PricingCardProps {
  name: string;
  price: string;
  description: string;
  features: string[];
  ctaText: string;
  ctaLink: string;
  popular?: boolean;
}

export function PricingCard({
  name,
  price,
  description,
  features,
  ctaText,
  ctaLink,
  popular = false,
}: PricingCardProps) {
  return (
    <Card className={cn(
      "relative flex flex-col p-6",
      popular && "border-orange-500 shadow-lg"
    )}>
      {popular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-orange-500 text-white text-sm font-medium rounded-full">
          Most Popular
        </div>
      )}
      <div className="mb-6">
        <h3 className="text-xl font-bold mb-2">{name}</h3>
        <div className="mb-2">
          <span className="text-3xl font-bold">{price}</span>
          {price !== "Custom" && <span className="text-muted-foreground">/month</span>}
        </div>
        <p className="text-muted-foreground">{description}</p>
      </div>

      <ul className="space-y-3 mb-6 flex-grow">
        {features.map((feature) => (
          <li key={feature} className="flex items-center gap-2">
            <Check className="h-4 w-4 text-green-500" />
            <span className="text-sm">{feature}</span>
          </li>
        ))}
      </ul>

      <Link href={ctaLink} className="w-full">
        <Button 
          className={cn(
            "w-full",
            popular && "bg-orange-500 hover:bg-orange-600"
          )}
          variant={popular ? "default" : "outline"}
        >
          {ctaText}
        </Button>
      </Link>
    </Card>
  );
}