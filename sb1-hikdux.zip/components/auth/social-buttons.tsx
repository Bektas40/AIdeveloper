"use client";

import { Twitter, Facebook, Instagram, Youtube } from "lucide-react";
import { Button } from "@/components/ui/button";
import { signIn } from "next-auth/react";
import { useState } from "react";
import { Loader2 } from "lucide-react";

interface SocialButtonProps {
  provider: string;
  icon: React.ReactNode;
  label: string;
  className?: string;
}

export function SocialButton({ provider, icon, label, className }: SocialButtonProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleClick = async () => {
    try {
      setIsLoading(true);
      await signIn(provider, { callbackUrl: "/dashboard" });
    } catch (error) {
      console.error("Social sign in error:", error);
    }
  };

  return (
    <Button
      variant="outline"
      className={className}
      onClick={handleClick}
      disabled={isLoading}
    >
      {isLoading ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Connecting...
        </>
      ) : (
        <>
          {icon}
          <span className="ml-2">{label}</span>
        </>
      )}
    </Button>
  );
}

export function SocialButtons() {
  const buttons = [
    {
      provider: "twitter",
      icon: <Twitter className="h-5 w-5" />,
      label: "Continue with X (Twitter)",
      className: "hover:bg-black hover:text-white",
    },
    {
      provider: "facebook",
      icon: <Facebook className="h-5 w-5" />,
      label: "Continue with Facebook",
      className: "hover:bg-blue-600 hover:text-white",
    },
    {
      provider: "google",
      icon: <Youtube className="h-5 w-5" />,
      label: "Continue with Google",
      className: "hover:bg-red-600 hover:text-white",
    },
  ];

  return (
    <div className="space-y-3">
      {buttons.map((button) => (
        <SocialButton key={button.provider} {...button} />
      ))}
    </div>
  );
}