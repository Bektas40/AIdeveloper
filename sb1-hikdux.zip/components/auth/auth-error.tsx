interface AuthErrorProps {
  message: string;
}

export function AuthError({ message }: AuthErrorProps) {
  return (
    <div className="rounded-md bg-destructive/15 p-3">
      <div className="flex">
        <div className="flex-1 text-sm font-medium text-destructive">
          {message}
        </div>
      </div>
    </div>
  );
}